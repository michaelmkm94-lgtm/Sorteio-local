# Sorteio — versão Netlify

Mesmo sistema do "Sorteio Local" (cadastro por valor da compra, fichas a cada R$ 50, sorteio com animação, resultados públicos), agora hospedado na internet:

| Quem | Endereço | Acesso |
|---|---|---|
| **Cliente** | `https://SEU-SITE.netlify.app` | livre (é o link do QR Code) |
| **ADM** | `https://SEU-SITE.netlify.app/admin` | pede a **senha** que você definir |

## Como funciona por baixo

- `public/` — site (HTML/CSS/JS), o mesmo da versão local.
- `netlify/functions/api.mjs` + `lib/app.mjs` — a API (antigo `app.py`), mesmas rotas e regras.
- Os dados ficam no **Netlify Blobs** (já incluso na conta, sem configurar banco). Alterações usam controle de concorrência por ETag: dois celulares enviando ao mesmo tempo nunca duplicam telefone nem ficha.
- A senha do ADM **não fica no código**: vem da variável de ambiente `ADMIN_PASSWORD`.
- O sorteio é **ponderado pelas fichas restantes**: quem tem 10 fichas tem 10 chances; ao ser sorteado passa a ter 9; quem tem 1 ficha sai ao ganhar.
- 8 senhas erradas seguidas bloqueiam aquele IP por 10 minutos.

## Publicar — opção A (recomendada): script

Pré-requisito: Node.js 22 ou superior (https://nodejs.org) e uma conta gratuita no Netlify.

1. Extraia esta pasta.
2. Dê dois cliques em **`publicar.bat`**.
3. Ele pergunta, nesta ordem:
   - login no Netlify (abre o navegador, só na 1ª vez);
   - **Nome do site** → ex.: `sorteio-mercado` (vira `sorteio-mercado.netlify.app`);
   - **Senha** do ADM → mínimo 8 caracteres, sem espaços nem `" % ^ & ! | < >`.
4. No final ele mostra os dois links.

Para atualizar depois, rode `publicar.bat` de novo e aperte **Enter** na pergunta da senha para manter a atual.

> O "arrastar e soltar" (Netlify Drop) **não serve** aqui: ele só publica arquivos estáticos e a API precisa rodar como função.

## Publicar — opção B: GitHub + painel do Netlify

1. Suba esta pasta para um repositório no GitHub (o `.gitignore` já está pronto).
2. No Netlify: **Add new project → Import an existing project → GitHub** e escolha o repositório.
3. Campos:
   - **Build command**: deixe vazio
   - **Publish directory**: `public`
   - **Functions directory**: `netlify/functions` (já vem do `netlify.toml`)
4. Antes de publicar, abra **Environment variables → Add a variable** e crie:
   - **Key**: `ADMIN_PASSWORD`
   - **Value**: a senha do ADM
   - **Scopes**: deixe **All scopes** (ou marque ao menos **Functions** e **Runtime**)
5. Clique em **Deploy**.

## Trocar a senha

Painel do Netlify → **Site configuration → Environment variables → ADMIN_PASSWORD → Edit**, salve e faça um novo deploy (**Deploys → Trigger deploy → Deploy project without cache**). Ou rode `publicar.bat` e digite a nova senha.

## Uso no evento

1. Abra `/admin`, entre com a senha e configure título, data, mensagem e prêmios (as fotos são reduzidas automaticamente para 900 px).
2. Em **Configuração** está o **QR Code do link do cliente**, com botão de imprimir.
3. Depois do evento, **Limpar todos os dados** zera fichas, prêmios e configurações para o próximo sorteio.

## Diferenças em relação à versão local

- Não há mais IP da rede/Wi-Fi: o QR Code aponta para o endereço `.netlify.app` e funciona em qualquer rede (4G incluso).
- O QR Code agora é gerado no navegador (biblioteca `qrcode-generator`, MIT).
- O "PIN" virou "senha" e vem de `ADMIN_PASSWORD` (não existe mais o padrão `1234`; sem a variável, o `/admin` recusa o login).
- A página pública é servida com cache de 3 s no CDN, para que muitos celulares consultando juntos não gerem uma execução por celular.

## Testes

`npm install` e depois `npm test` — roda 12 testes da API (cadastro, duplicidade, corrida entre 40 cadastros simultâneos, sorteio ponderado pelas fichas, senha e bloqueio, reset).
