const $ = (s) => document.querySelector(s);
const state = { pin: sessionStorage.getItem('sorteio_pin') || '', admin: null, selectedPrize: null, lastWinner: null, deviceId: getDeviceId(), wasRegistered: false, publicWasActive: false };
function getDeviceId(){ const key='sorteio_local_device_id_v1'; try { let id=localStorage.getItem(key); if(!id){ const bytes=new Uint8Array(24); if(window.crypto?.getRandomValues) crypto.getRandomValues(bytes); else for(let i=0;i<bytes.length;i++) bytes[i]=Math.floor(Math.random()*256); id='device-'+Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join(''); localStorage.setItem(key,id); } return id; } catch(e) { return 'device-'+Array.from({length:48},()=>Math.floor(Math.random()*16).toString(16)).join(''); } }
function showGoodLuck(ticketCount=1){ $('#entryForm').dataset.unlocked='0'; $('#entryForm').classList.add('hidden'); $('#amountEntryStage').classList.add('hidden'); $('#amountConfirmStage').classList.add('hidden'); $('#goodLuckScreen').classList.remove('hidden'); const n=Math.max(1,Number(ticketCount)||1); const label=$('#goodLuckTicketCount'); if(label)label.textContent=`Você tem ${n} ${n===1?'ficha':'fichas'}.`; }
async function checkDeviceRegistration(){ try{ const d=await api('/api/entries/status?device_id='+encodeURIComponent(state.deviceId)); if(d.registered) showGoodLuck(d.tickets_total||1); }catch(e){} }
const api = async (url, options = {}) => { const headers = {'Content-Type':'application/json', ...(options.headers || {})}; if (state.pin) headers['X-Admin-Pin'] = state.pin; const r = await fetch(url, {...options, headers}); const d = await r.json().catch(() => ({})); if(!r.ok) throw new Error(d.error || `Falha HTTP ${r.status}.`); return d; };
const esc = (v='') => String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const toast = (msg, bad=false) => { const el=$('#toast'); el.textContent=msg; el.className='toast show '+(bad?'bad':''); setTimeout(()=>el.className='toast',3200); };
function applyTheme(settings){ document.documentElement.style.setProperty('--cyan', settings.accent_color || '#77e5dc'); document.body.dataset.theme=settings.visual_theme || 'neon-night'; }
function formatDrawDateTime(drawDate, drawTime){
 // Formata os valores ISO dos inputs date/time sem Date(), evitando conversões de fuso horário.
 const dateMatch=String(drawDate||'').match(/^(\d{4})-(\d{2})-(\d{2})$/);
 const timeMatch=String(drawTime||'').match(/^(\d{2}):(\d{2})$/);
 if(!dateMatch) return '';
 const date=`${dateMatch[3]}/${dateMatch[2]}/${dateMatch[1]}`;
 return timeMatch?`${date} às ${timeMatch[1]}:${timeMatch[2]}`:date;
}
async function refreshPublicDisplay(){
 // Atualiza somente informações públicas/resultados. Nunca altera a etapa do cadastro,
 // pois uma resposta de polling não deve interferir na confirmação do valor.
 const d=await api('/api/public');
 $('#publicTitle').textContent=d.settings.draw_title||'Sorteio Local';
 const formattedDate=formatDrawDateTime(d.settings.draw_date,d.settings.draw_time);
 $('#drawDateLabel').textContent=formattedDate||'Data e hora ainda não configuradas';
 const active=d.settings.draw_status==='running'||d.settings.draw_status==='finished';
 $('#publicDrawStatus').classList.toggle('hidden',!active);
 if(active){
   state.publicWasActive=true;
   $('#amountEntryStage').classList.add('hidden');$('#amountConfirmStage').classList.add('hidden');$('#entryForm').classList.add('hidden');$('#goodLuckScreen').classList.add('hidden');
   $('#publicDrawStatusTitle').textContent=d.settings.draw_status==='finished'?'Sorteio finalizado':'Sorteio em andamento';
   $('#publicDrawResults').innerHTML=(d.results||[]).length?d.results.map(r=>`<article class="public-result-text"><strong>${esc(r.prize_name)}</strong><span>Ganhador: ${esc(r.full_name)}${r.nickname?` (“${esc(r.nickname)}”)`:''}</span><small>${r.drawn_at?new Date(r.drawn_at).toLocaleString('pt-BR'):'Resultado confirmado'}</small></article>`).join(''):'<p class="empty-state">Os resultados aparecerão aqui quando cada prêmio for sorteado.</p>';
   $('#publicMessage').textContent=d.settings.draw_status==='finished'?'Sorteio finalizado. Confira abaixo os ganhadores.':'Sorteio em andamento. Os ganhadores serão exibidos abaixo.';
 }else{
   if(state.publicWasActive){state.publicWasActive=false;resetPublicRegistrationView();}
   $('#publicMessage').textContent=d.settings.public_message||'Preencha seus dados e informe o valor total da compra.';
 }
}
function resetPublicRegistrationView(){
 state.wasRegistered=false; const form=$('#entryForm'); form.reset(); form.dataset.unlocked='0'; form.dataset.submitting='0'; $('#purchaseAmount').value=''; $('#confirmedPurchaseAmount').value=''; $('#entryFeedback').textContent=''; $('#formFeedback').textContent=''; $('#amountEntryStage').classList.remove('hidden'); $('#amountConfirmStage').classList.add('hidden'); form.classList.add('hidden'); $('#goodLuckScreen').classList.add('hidden');
}

function showAmountConfirmation(amount, ticketCount){
 $('#amountToConfirm').textContent=formatBRL(amount);
 $('#amountTicketEstimate').textContent=`${ticketCount} ${ticketCount===1?'ficha prevista':'fichas previstas'}`;
 $('#confirmedPurchaseAmount').value=Number(amount).toFixed(2).replace('.',',');
 $('#amountEntryStage').classList.add('hidden');$('#amountConfirmStage').classList.remove('hidden');$('#entryForm').classList.add('hidden');
}
async function loadPublic(){
 const d=await api('/api/public');
 $('#publicTitle').textContent=d.settings.draw_title||'Sorteio Local';
 const formattedDate=formatDrawDateTime(d.settings.draw_date,d.settings.draw_time);
 $('#drawDateLabel').textContent=formattedDate||'Data e hora ainda não configuradas';
 const registered=await api('/api/entries/status?device_id='+encodeURIComponent(state.deviceId)).catch(()=>({registered:false}));
 const active=d.settings.draw_status==='running'||d.settings.draw_status==='finished';
 $('#publicDrawStatus').classList.toggle('hidden',!active);
 if(active){
   $('#amountEntryStage').classList.add('hidden');$('#amountConfirmStage').classList.add('hidden');$('#entryForm').classList.add('hidden');$('#goodLuckScreen').classList.add('hidden');
   $('#publicDrawStatusTitle').textContent=d.settings.draw_status==='finished'?'Sorteio finalizado':'Sorteio em andamento';
   $('#publicDrawResults').innerHTML=(d.results||[]).length?d.results.map(r=>`<article class="public-result-text"><strong>${esc(r.prize_name)}</strong><span>Ganhador: ${esc(r.full_name)}${r.nickname?` (“${esc(r.nickname)}”)`:''}</span><small>${r.drawn_at?new Date(r.drawn_at).toLocaleString('pt-BR'):'Resultado confirmado'}</small></article>`).join(''):'<p class="empty-state">Os resultados aparecerão aqui quando cada prêmio for sorteado.</p>';
   $('#publicMessage').textContent=d.settings.draw_status==='finished'?'Sorteio finalizado. Confira abaixo os ganhadores.':'Sorteio em andamento. Os ganhadores serão exibidos abaixo.';
 } else {
   if(state.publicWasActive){state.publicWasActive=false;resetPublicRegistrationView();}
   $('#publicMessage').textContent=d.settings.public_message||'Preencha seus dados e informe o valor total da compra.';
 }
 if(active){state.publicWasActive=true;return;}
 if(registered.registered){
   state.wasRegistered=true;
   showGoodLuck(registered.tickets_total||1);
   $('#amountEntryStage').classList.add('hidden');$('#amountConfirmStage').classList.add('hidden');$('#entryForm').classList.add('hidden');
   return;
 }
 if($('#entryForm').dataset.unlocked==='1'){
   return;
 }
 if(registered.amount_pending){
   showAmountConfirmation(registered.purchase_amount, registered.tickets_total||1);
   return;
 }
 if(state.wasRegistered){state.wasRegistered=false;$('#entryForm').reset();delete $('#entryForm').dataset.unlocked;$('#purchaseAmount').value='';$('#amountEntryStage').classList.remove('hidden');$('#amountConfirmStage').classList.add('hidden');}
 if(active){$('#amountEntryStage').classList.add('hidden');$('#amountConfirmStage').classList.add('hidden');$('#entryForm').classList.add('hidden');$('#goodLuckScreen').classList.add('hidden');return;}
 // Não reinicie a etapa de valor durante a atualização automática do site.
 // A conferência deve permanecer aberta até o cliente confirmar ou corrigir com PIN.
 const confirmingAmount=!$('#amountConfirmStage').classList.contains('hidden');
 const registrationUnlocked=$('#entryForm').dataset.unlocked==='1';
 if(!registrationUnlocked&&!confirmingAmount){$('#amountEntryStage').classList.remove('hidden');$('#amountConfirmStage').classList.add('hidden');$('#entryForm').classList.add('hidden');$('#goodLuckScreen').classList.add('hidden');}
}

function parseCurrencyInput(value){
 let raw=String(value||'').trim().replace(/R\$/gi,'').replace(/\s/g,'');
 if(!raw)return null;
 if(!/^(?:\d{1,6}|\d{1,3}(?:\.\d{3})+)(?:,\d{2}|\.\d{2})$/.test(raw))return null;
 raw=raw.replace(/\./g,'').replace(',','.');
 const n=Number(raw);return Number.isFinite(n)&&n>=0&&n<=999999.99?Math.round(n*100)/100:null;
}
function formatBRL(value){return Number(value).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});}
function formatCurrencyTyping(input){
 const digits=String(input.value||'').replace(/\D/g,'').slice(0,8);
 if(!digits){input.value='';return;}
 const cents=Number(digits);
 input.value=(cents/100).toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2,useGrouping:false});
}
async function updateAmountConfirmation(){
 const input=$('#purchaseAmount'), parsed=parseCurrencyInput(input.value), feedback=$('#entryFeedback');
 if(parsed===null){feedback.textContent='Digite o valor da compra. Exemplo: 300,00.';feedback.className='feedback error';return;}
 const button=$('#confirmAmountButton');button.disabled=true;feedback.textContent='Registrando valor para conferência…';feedback.className='feedback';
 try{const result=await api('/api/entries/amount',{method:'POST',body:JSON.stringify({device_id:state.deviceId,purchase_amount:parsed.toFixed(2).replace('.',',')})});showAmountConfirmation(result.purchase_amount,result.tickets_total);feedback.textContent='';}
 catch(err){feedback.textContent=err.message;feedback.className='feedback error';}
 finally{button.disabled=false;}
}
async function correctPurchaseAmount(){
 const pin=prompt('Para corrigir o valor, informe a senha administrativa:');
 if(pin===null)return;
 try{await api('/api/auth',{method:'POST',body:JSON.stringify({pin})});await api('/api/entries/amount/reset',{method:'POST',body:JSON.stringify({pin,device_id:state.deviceId})});$('#amountConfirmStage').classList.add('hidden');$('#amountEntryStage').classList.remove('hidden');$('#entryForm').classList.add('hidden');$('#purchaseAmount').value='';$('#purchaseAmount').focus();}
 catch(e){alert((e&&e.message&&!/^Falha HTTP/.test(e.message)&&!/inválida/.test(e.message))?e.message:'Senha administrativa incorreta. O valor não foi alterado.');}
}

async function submitEntry(e){
 e.preventDefault();const form=e.target,button=form.querySelector('button[type=submit]');
 if(form.dataset.submitting==='1')return;
 const consent=form.querySelector('input[type="checkbox"][required]');
 if(consent&&!consent.checked){$('#formFeedback').textContent='Marque a caixa de concordância para finalizar o cadastro.';$('#formFeedback').className='feedback error';return;}
 form.dataset.submitting='1';const data=Object.fromEntries(new FormData(form));
 if(!String(data.full_name||'').trim()||!String(data.address||'').trim()){$('#formFeedback').textContent='Preencha seu nome completo e endereço.';$('#formFeedback').className='feedback error';form.dataset.submitting='0';return;}
 const amount=parseCurrencyInput(data.purchase_amount);
 if(amount===null){$('#formFeedback').textContent='Informe o valor no formato 000,00 (ex.: 300,00).';$('#formFeedback').className='feedback error';form.dataset.submitting='0';return;}
 if(!$('#entryForm').dataset.unlocked){$('#formFeedback').textContent='Confirme primeiro o valor da compra com o operador do caixa.';$('#formFeedback').className='feedback error';form.dataset.submitting='0';return;}
 data.purchase_amount=amount.toFixed(2).replace('.',',');
 data.phone=String(data.phone||'').replace(/\D/g,'');data.phone2=String(data.phone2||'').replace(/\D/g,'');
 for(const k of ['phone','phone2'])if(data[k].length===13&&data[k].startsWith('55'))data[k]=data[k].slice(2);
 if(data.phone2&&data.phone2===data.phone){$('#formFeedback').textContent='Telefone 1 e Telefone 2 não podem ser iguais.';$('#formFeedback').className='feedback error';form.dataset.submitting='0';return;}
 if(data.phone.length!==11||data.phone[2]!=='9'||(data.phone2&&(data.phone2.length!==11||data.phone2[2]!=='9'))){$('#formFeedback').textContent='Informe celulares brasileiros válidos com DDD e 11 dígitos.';$('#formFeedback').className='feedback error';form.dataset.submitting='0';return;}
 data.device_id=state.deviceId;button.disabled=true;
 try{const result=await api('/api/entries',{method:'POST',body:JSON.stringify(data)});form.reset();showGoodLuck(result.tickets_total||1);toast('Participação confirmada. Boa sorte!');}
 catch(err){if(err.message.includes('já possui uma ficha')){const current=await api('/api/entries/status?device_id='+encodeURIComponent(state.deviceId)).catch(()=>({}));if(current.registered){showGoodLuck(current.tickets_total||1);return;}}$('#formFeedback').textContent=err.message;$('#formFeedback').className='feedback error';}
 finally{button.disabled=false;form.dataset.submitting='0';}
}
async function login(e){if(e)e.preventDefault();const pin=e?$('#pinInput').value:state.pin;try{await api('/api/auth',{method:'POST',body:JSON.stringify({pin})});state.pin=pin;sessionStorage.setItem('sorteio_pin',pin);$('#loginPanel').classList.add('hidden');$('#dashboard').classList.remove('hidden');await loadAdmin();}catch(err){$('#loginFeedback').textContent=(err&&err.message&&!/^Falha HTTP/.test(err.message))?err.message:'Senha inválida.';state.pin='';sessionStorage.removeItem('sorteio_pin');}}
async function loadAdmin(){ state.admin=await api('/api/admin'); const s=state.admin.settings; applyTheme(s); $('#adminTitle').textContent=s.draw_title; $('#entryStat').textContent=state.admin.entries.length; $('#liveEntryCount').textContent=state.admin.entries.length; const totalTickets=state.admin.entries.reduce((n,x)=>n+Number(x.tickets_total||1),0); const availableTickets=state.admin.entries.reduce((n,x)=>n+Math.max(0,Number(x.tickets_total||1)-Number(x.tickets_drawn||0)),0); $('#ticketStat').textContent=totalTickets; $('#ticketStatDetail').textContent=`${availableTickets} disponíveis`; $('#prizeStat').textContent=state.admin.prizes.length; $('#settingsForm [name=draw_title]').value=s.draw_title; $('#settingsForm [name=draw_date]').value=s.draw_date || ''; $('#settingsForm [name=draw_time]').value=s.draw_time || '';  $('#settingsForm [name=public_message]').value=s.public_message || ''; $('#settingsForm [name=accent_color]').value=s.accent_color || '#77e5dc'; $('#settingsForm [name=visual_theme]').value=s.visual_theme || 'neon-night'; renderAdminPrizes();renderDrawList();renderEntries();renderHistory();try{const url=location.origin;$('#networkUrl').textContent=url.replace(/^https?:\/\//,'');$('#qrUrl').textContent=url;if($('#qrcode').dataset.url!==url){const qr=qrcode(0,'M');qr.addData(url);qr.make();$('#qrcode').innerHTML=qr.createSvgTag({cellSize:8,margin:0,scalable:true});$('#qrcode').dataset.url=url;const svg=$('#qrcode svg');if(svg){svg.removeAttribute('width');svg.removeAttribute('height');svg.setAttribute('role','img');svg.setAttribute('aria-label','QR Code de acesso');}}}catch(e){}}
function renderAdminPrizes(){ $('#adminPrizes').innerHTML=state.admin.prizes.length?state.admin.prizes.map(p=>`<div class="admin-prize"><div class="thumb">${p.image?`<img src="${p.image}">`:'✦'}</div><div><strong>${esc(p.name)}</strong><small>${esc(p.description)}</small></div><span class="order-badge">${p.drawn?'✓ sorteado':'#'+p.sort_order}</span>${!p.drawn?`<button class="icon-button" onclick="deletePrize(${p.id})">×</button>`:''}</div>`).join(''):'<div class="empty-state">Nenhum item adicionado.</div>'; }
function updateDrawAvailability(){
 const available=(state.admin?.prizes||[]).filter(p=>!p.drawn);
 const finished=available.length===0;
 $('#drawIdleTitle').textContent=finished?'Sorteio finalizado':'Escolha um item para começar';
 $('#drawIdleMessage').textContent=finished?'Todos os itens da ordem de sorteio já foram sorteados.':'O participante sorteado será removido automaticamente das próximas rodadas.';
 $('#runDrawButton').classList.toggle('hidden',finished);
 if(finished){state.selectedPrize=null;}
}
function renderDrawList(){ $('#drawPrizeList').innerHTML=state.admin.prizes.length?state.admin.prizes.map(p=>`<button class="draw-prize ${p.drawn?'done':''} ${state.selectedPrize===p.id?'selected':''}" ${p.drawn?'disabled':''} onclick="selectPrize(${p.id})"><span>${p.drawn?'✓':String(p.sort_order).padStart(2,'0')}</span><strong>${esc(p.name)}</strong></button>`).join(''):'<div class="empty-state">Adicione prêmios na configuração.</div>'; updateDrawAvailability(); }
async function refreshLiveCount(){ try{const d=await api('/api/public'); const n=d.participant_count; $('#liveEntryCount').textContent=n; $('#entryStat').textContent=n; $('#ticketStat').textContent=d.total_tickets; $('#ticketStatDetail').textContent=`${d.available_tickets} disponíveis`; if(state.pin && !$('#adminView').classList.contains('hidden') && !$('#entriesTab').classList.contains('hidden') && !$('#adminView').classList.contains('draw-focus')) await loadAdmin(); }catch(e){} }
function renderHistory(){const drawn=(state.admin?.entries||[]);const prizes=(state.admin?.prizes||[]).filter(p=>p.drawn);const pairs=prizes.map(p=>({prize:p,winner:drawn.find(e=>Number(e.id)===Number(p.winner_entry_id))})).filter(x=>x.winner);$('#drawHistory').innerHTML=pairs.length?pairs.map((x,i)=>`<article class="history-item"><span class="history-number">${i+1}</span><div class="history-prize-image">${x.prize.image?`<img src="${x.prize.image}" alt="${esc(x.prize.name)}">`:'✦'}</div><div class="history-copy"><h3>${esc(x.prize.name)}</h3><strong>${esc(x.winner.full_name)}</strong><p>${esc(x.winner.address)}</p><p>Telefone 1: ${esc(x.winner.phone)}</p><p>Telefone 2: ${esc(x.winner.phone2||'Não informado')}</p><small>${x.winner.drawn_at?new Date(x.winner.drawn_at).toLocaleString('pt-BR'):'Resultado registrado'}</small></div></article>`).join(''):'<div class="empty-state">Os ganhadores aparecerão aqui após cada sorteio.</div>'; }
function renderEntries(){const available=state.admin.entries.reduce((n,x)=>n+Math.max(0,Number(x.tickets_total||1)-Number(x.tickets_drawn||0)),0);const total=state.admin.entries.reduce((n,x)=>n+Number(x.tickets_total||1),0);$('#entryCountLabel').textContent=`${state.admin.entries.length} participantes · ${total} fichas totais · ${available} disponíveis`;$('#entriesTable').innerHTML=state.admin.entries.length?`<div class="table-head"><span>Participante / comprovante</span><span>Contato</span><span>Fichas / ações</span></div>`+state.admin.entries.map(e=>{const total=Number(e.tickets_total||1),used=Number(e.tickets_drawn||0),left=Math.max(0,total-used);return `<article class="participant-row"><div><strong>${esc(e.full_name)}</strong>${e.nickname?`<small>“${esc(e.nickname)}”</small>`:''}<small>Endereço: ${esc(e.address)}</small><div class="purchase-proof"><div><b>Valor informado:</b> ${e.purchase_amount==null?'Não informado':`R$ ${Number(e.purchase_amount).toLocaleString('pt-BR',{minimumFractionDigits:2})}`}<small>Conferir com o comprovante do caixa</small></div></div></div><div>${esc(e.phone)}<small>Telefone 2: ${esc(e.phone2||'Não informado')}</small></div><div><strong>${left} disponíveis / ${total} liberadas</strong><small>${used} já sorteadas</small><button class="secondary-button release-ticket-button" data-release-entry="${e.id}">Liberar ficha</button></div></article>`;}).join(''):'<div class="empty-state">Ainda não há participantes.</div>'; }
window.deletePrize=async id=>{if(!confirm('Remover este item?'))return;await api('/api/prizes/delete',{method:'POST',body:JSON.stringify({pin:state.pin,id})});await loadAdmin();}; window.selectPrize=id=>{state.selectedPrize=id;renderDrawList();$('#drawIdle').classList.remove('hidden');$('#drawWinner').classList.add('hidden');};
async function saveSettings(e){e.preventDefault();const d=Object.fromEntries(new FormData(e.target));d.pin=state.pin;try{await api('/api/settings',{method:'POST',body:JSON.stringify(d)});$('#settingsFeedback').textContent='Configurações salvas.';$('#settingsFeedback').className='feedback success';await loadAdmin();await loadPublic();}catch(err){toast(err.message,true);}}
async function addPrize(e){e.preventDefault();const d=Object.fromEntries(new FormData(e.target));const file=e.target.image.files[0];if(file){d.image=await shrinkImage(file);}d.pin=state.pin;try{await api('/api/prizes',{method:'POST',body:JSON.stringify(d)});e.target.reset();$('#prizeFeedback').textContent='Item adicionado à ordem do sorteio.';$('#prizeFeedback').className='feedback success';await loadAdmin();await loadPublic();}catch(err){toast(err.message,true);}}
async function performDraw(){
 if(!state.selectedPrize){toast('Selecione o item que será sorteado.',true);return;}
 // Atualiza a lista diretamente do servidor antes de validar: a inscrição pode ter
 // chegado de outro aparelho depois da última atualização do painel.
 const button=$('#runDrawButton');button.disabled=true;
 try { await loadAdmin(); }
 catch(err) { button.disabled=false; toast('Não foi possível atualizar os participantes. Verifique a conexão e tente novamente.',true); return; }
 if(!state.admin || !Array.isArray(state.admin.entries)) { button.disabled=false; toast('Não foi possível confirmar a lista de participantes.',true); return; }
 if(!state.admin.prizes.some(p=>Number(p.id)===Number(state.selectedPrize)&&!p.drawn)) { button.disabled=false; state.selectedPrize=null; renderDrawList(); toast('O prêmio selecionado não está mais disponível. Selecione novamente.',true); return; }
 const available=state.admin.entries.filter(x=>Number(x.tickets_total||1)>Number(x.tickets_drawn||0));
 if(!available.length){button.disabled=false;toast('Não há participantes disponíveis. Confirme a aba Participantes e tente novamente.',true);return;}
 $('#adminView').classList.add('draw-focus');$('#drawIdle').classList.add('hidden');$('#drawWinner').classList.add('hidden');$('#drawAnimation').classList.remove('hidden');createTicketVortex();
 try{
  await api('/api/draw/start',{method:'POST',body:JSON.stringify({pin:state.pin,prize_id:state.selectedPrize})});
  await new Promise(r=>setTimeout(r,6000));
  // O resultado real é decidido no servidor ao final da animação inicial.
  const d=await api('/api/draw',{method:'POST',body:JSON.stringify({pin:state.pin,prize_id:state.selectedPrize})});
  state.lastWinner=d;updateTicketVortexWinner(d);await new Promise(r=>setTimeout(r,900));
  $('#ticketVortex').classList.add('ticket-vortex-final');await new Promise(r=>setTimeout(r,900));
  $('#drawAnimation').classList.add('hidden');$('#drawWinner').classList.remove('hidden');
  $('#winnerName').textContent=d.winner.full_name||'';$('#winnerAddress').textContent=d.winner.address||'Não informado';$('#winnerPhone').textContent=d.winner.phone||'Não informado';$('#winnerPhone2').textContent=d.winner.phone2||'Não informado';$('#winnerNickname').textContent=d.winner.nickname||'—';$('#winnerDetails').textContent=`Ficha nº ${d.winner.id}`;
  $('#winnerPrize').innerHTML=`${d.prize.image?`<img src="${d.prize.image}" alt="${esc(d.prize.name)}">`:'<div class="prize-placeholder">✦</div>'}<strong>${esc(d.prize.name)}</strong>`;
  spawnConfetti();await loadAdmin();await loadPublic();
 }catch(err){toast(err.message,true);$('#drawAnimation').classList.add('hidden');$('#drawIdle').classList.remove('hidden');}
 finally{button.disabled=false;$('#ticketVortex').innerHTML='';$('#ticketVortex').classList.remove('ticket-vortex-final');}
}
function createTicketVortex(d){
 const root=$('#ticketVortex');root.classList.remove('ticket-vortex-final');
 const w=d?.winner||{};const winnerCard=`<span class="ticket-winner-face"><b>FICHA SORTEADA</b><strong>${esc(w.full_name||'Participante')}</strong><small>${esc(w.address||'Endereço não informado')}</small><small>Telefone 1: ${esc(w.phone||'Não informado')}</small><small>Telefone 2: ${esc(w.phone2||'Não informado')}</small></span>`;
 root.innerHTML=Array.from({length:42},(_,i)=>{const selected=i===20;return `<span class="flying-ticket ${selected?'flying-ticket-selected':''}" style="--i:${i};--angle:${i*137.507764}deg;--delay:${(i%14)*-.13}s;--radius:${110+(i%7)*34}px;--depth:${(i%5)*55}px">${selected?winnerCard:`<b>FICHA</b><small>${String(i+1).padStart(3,'0')}</small>`}</span>`;}).join('');
 }
function updateTicketVortexWinner(d){const selected=$('#ticketVortex .flying-ticket-selected');if(!selected)return;const w=d?.winner||{};selected.innerHTML=`<span class="ticket-winner-face"><b>FICHA SORTEADA</b><strong>${esc(w.full_name||'Participante')}</strong><small>${esc(w.address||'Endereço não informado')}</small><small>Telefone 1: ${esc(w.phone||'Não informado')}</small><small>Telefone 2: ${esc(w.phone2||'Não informado')}</small></span>`;}

// Reduz a foto do prêmio no próprio navegador (máx. 900 px, JPEG) para caber no envio e carregar rápido nos celulares.
async function shrinkImage(file){
 const dataUrl=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(file);});
 try{
  const img=await new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=rej;i.src=dataUrl;});
  const scale=Math.min(1,900/Math.max(img.naturalWidth,img.naturalHeight));
  const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
  const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
  return canvas.toDataURL('image/jpeg',0.82);
 }catch(e){return dataUrl;}
}
function spawnConfetti(){const box=document.querySelector('.confetti');box.innerHTML=Array.from({length:28},(_,i)=>`<i style="--x:${Math.random()*100}%;--r:${Math.random()*360}deg;--d:${1+Math.random()*1.5}s"></i>`).join('');}
function showAdmin(){
 // /admin usa o mesmo HTML da página pública; alterna explicitamente para a interface do gerenciador.
 $('#publicView').classList.add('hidden');
 $('#adminView').classList.remove('hidden');
 $('#loginPanel').classList.remove('hidden');
 $('#dashboard').classList.add('hidden');
 if(state.pin) login(null);
}
function switchTab(name){document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===name));document.querySelectorAll('.tab-panel').forEach(x=>x.classList.add('hidden'));$(`#${name}Tab`).classList.remove('hidden');if(name!=='draw')$('#adminView').classList.remove('draw-focus');}
const on = (selector, event, handler) => { const element = $(selector); if (element) element.addEventListener(event, handler); };

on('#confirmAmountButton','click',updateAmountConfirmation);
on('#purchaseAmount','input',()=>formatCurrencyTyping($('#purchaseAmount'))); on('#operatorConfirmButton','click',()=>{ $('#amountConfirmStage').classList.add('hidden');$('#entryForm').classList.remove('hidden');$('#entryForm').dataset.unlocked='1';$('#entryForm').elements.purchase_amount.value=$('#confirmedPurchaseAmount').value; }); on('#correctAmountButton','click',correctPurchaseAmount);
on('#entriesTable','click',async e=>{const btn=e.target.closest('[data-release-entry]');if(!btn)return;const raw=prompt('Quantas fichas adicionais deseja liberar para este participante?', '1');if(raw===null)return;const tickets=Number.parseInt(raw,10);if(!Number.isInteger(tickets)||tickets<1||tickets>1000){toast('Informe uma quantidade entre 1 e 1000.',true);return;}btn.disabled=true;try{await api('/api/entries/release',{method:'POST',body:JSON.stringify({pin:state.pin,entry_id:Number(btn.dataset.releaseEntry),tickets})});await loadAdmin();await loadPublic();toast(`${tickets} ${tickets===1?'ficha liberada':'fichas liberadas'}.`);}catch(err){toast(err.message,true);}finally{btn.disabled=false;}});
on('#manualEntryForm','submit',async e=>{e.preventDefault();const form=e.target,button=form.querySelector('button[type=submit]'),feedback=$('#manualEntryFeedback');const data=Object.fromEntries(new FormData(form));data.pin=state.pin;data.phone=String(data.phone||'').replace(/\D/g,'');data.phone2=String(data.phone2||'').replace(/\D/g,'');if(data.phone2&&data.phone===data.phone2){feedback.textContent='Telefone 1 e Telefone 2 não podem ser iguais.';feedback.className='feedback error';return;}const amount=parseCurrencyInput(data.purchase_amount||'0,00');if(amount===null){feedback.textContent='Informe o valor no formato 300,00.';feedback.className='feedback error';return;}data.purchase_amount=amount.toFixed(2).replace('.',',');button.disabled=true;feedback.textContent='';try{const result=await api('/api/admin/entries',{method:'POST',body:JSON.stringify(data)});form.reset();form.elements.purchase_amount.value='0,00';feedback.textContent=`Participante cadastrado. ${result.tickets_total} ficha(s) liberada(s).`;feedback.className='feedback success';await loadAdmin();await loadPublic();}catch(err){feedback.textContent=err.message;feedback.className='feedback error';}finally{button.disabled=false;}}); on('#entryForm','submit',submitEntry); on('#loginForm','submit',login); on('#settingsForm','submit',saveSettings); on('#prizeForm','submit',addPrize); on('#runDrawButton','click',performDraw); on('#startDrawButton','click',()=>switchTab('draw')); on('#printQr','click',()=>window.print()); on('#resetButton','click',async()=>{if(confirm('Isto apagará todas as fichas e prêmios. Continuar?')){await api('/api/reset',{method:'POST',body:JSON.stringify({pin:state.pin})});state.selectedPrize=null;$('#adminView').classList.remove('draw-focus');await loadAdmin();await loadPublic();toast('Dados limpos para um novo sorteio.');}}); on('#nextDrawButton','click',()=>{
 // Sai do modo de tela cheia do ganhador e volta diretamente à aba principal Sorteio.
 // O modo draw-focus oculta a lista de prêmios; precisa ser removido explicitamente.
 $('#adminView').classList.remove('draw-focus');
 state.selectedPrize=null;
 $('#drawAnimation').classList.add('hidden');
 $('#drawWinner').classList.add('hidden');
 $('#drawIdle').classList.remove('hidden');
 switchTab('draw');
 renderDrawList();
 $('#drawTab').scrollIntoView({behavior:'instant',block:'start'});
}); on('#finishDrawButton','click',async()=>{if(!confirm('Finalizar o sorteio? Os resultados continuarão visíveis no site.'))return;try{await api('/api/draw/finish',{method:'POST',body:JSON.stringify({pin:state.pin})});await loadPublic();switchTab('config');toast('Sorteio finalizado.');}catch(err){toast(err.message,true);}}); document.querySelectorAll('.tab').forEach(t=>t.addEventListener('click',()=>switchTab(t.dataset.tab))); setInterval(refreshLiveCount,3000); setInterval(()=>{if(!$('#publicView').classList.contains('hidden'))refreshPublicDisplay().catch(()=>{});},5000);
if(/^\/admin\/?$/.test(location.pathname))showAdmin();else loadPublic().then(checkDeviceRegistration);
if('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(()=>{});
