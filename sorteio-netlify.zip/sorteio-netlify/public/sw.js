const CACHE='sorteio-netlify-v23';
const APP_SHELL=['/','/index.html','/styles.css','/app.js','/qrcode.js','/manifest.json'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const requestUrl = new URL(event.request.url);
  if (event.request.method !== 'GET' || requestUrl.origin !== location.origin || requestUrl.pathname.startsWith('/api/')) return;
  const isAppCode = requestUrl.pathname === '/app.js' || requestUrl.pathname === '/sw.js' || requestUrl.pathname === '/index.html' || requestUrl.pathname === '/';
  if (isAppCode) {
    event.respondWith(fetch(event.request, { cache: 'no-store' }).then(response => {
      if (response.ok && requestUrl.pathname !== '/sw.js') {
        const copy = response.clone();
        caches.open(CACHE).then(cache => cache.put(event.request, copy));
      }
      return response;
    }).catch(() => caches.match(event.request).then(response => response || caches.match('/index.html'))));
  } else {
    event.respondWith(caches.match(event.request).then(response => response || fetch(event.request)));
  }
});
