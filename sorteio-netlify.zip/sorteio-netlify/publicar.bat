@echo off
chcp 65001 >nul
title Publicar Sorteio no Netlify
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao encontrado. Instale a versao 22 ou superior em https://nodejs.org e execute de novo.
  pause
  exit /b 1
)
node scripts\publicar.mjs
echo.
pause
