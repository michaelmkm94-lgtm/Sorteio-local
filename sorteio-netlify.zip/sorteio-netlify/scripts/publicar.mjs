// Publica o Sorteio no Netlify: cria o site (1ª vez), grava a senha do ADM e envia a versão de produção.
// Uso: execute "publicar.bat" (Windows) ou "node scripts/publicar.mjs".
import { spawnSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { createInterface } from "node:readline/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";

const raiz = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
process.chdir(raiz);
const rl = createInterface({ input: process.stdin, output: process.stdout });
const NETLIFY = ["--yes", "netlify-cli@latest"];

function rodar(args, { capturar = false } = {}) {
  const r = spawnSync("npx", [...NETLIFY, ...args], {
    stdio: capturar ? ["inherit", "pipe", "inherit"] : "inherit",
    shell: true, // necessário no Windows (npx.cmd)
    encoding: "utf8",
  });
  return r;
}
const falhar = (msg) => { console.error("\n❌ " + msg); rl.close(); process.exit(1); };

console.log("\n=== Publicar Sorteio no Netlify ===\n");

console.log("1/5  Instalando dependências…");
if (spawnSync("npm", ["install", "--no-audit", "--no-fund"], { stdio: "inherit", shell: true }).status !== 0) {
  falhar("Falha no npm install. Verifique a internet e se o Node.js 22 ou superior está instalado.");
}

console.log("\n2/5  Verificando login no Netlify…");
const status = rodar(["status"], { capturar: true });
if (status.status !== 0 || /not logged in|not signed in/i.test(status.stdout || "")) {
  console.log("Abrindo o navegador para você entrar na sua conta Netlify…");
  if (rodar(["login"]).status !== 0) falhar("Não foi possível entrar na conta Netlify.");
}

const estado = path.join(raiz, ".netlify", "state.json");
let primeiraVez = !existsSync(estado);
if (primeiraVez) {
  console.log("\n3/5  Criando o site no Netlify.");
  console.log("     O nome vira o endereço: NOME.netlify.app (só letras minúsculas, números e hífen).");
  for (;;) {
    const nome = (await rl.question("     Nome do site (ex.: sorteio-mercado): ")).trim().toLowerCase();
    if (!/^[a-z0-9][a-z0-9-]{2,60}$/.test(nome)) { console.log("     Nome inválido. Tente de novo."); continue; }
    if (rodar(["sites:create", "--name", nome]).status === 0) break;
    console.log("     Não foi possível criar com esse nome (talvez já exista). Tente outro.");
  }
} else {
  console.log("\n3/5  Site já vinculado a esta pasta (" + JSON.parse(readFileSync(estado, "utf8")).siteId + ").");
}

console.log("\n4/5  Senha do administrador (usada em /admin).");
console.log("     Mínimo 8 caracteres. Não use espaços nem os símbolos  \" % ^ & ! | < >");
for (;;) {
  const dica = primeiraVez ? "" : " (Enter = manter a atual)";
  const senha = (await rl.question("     Senha" + dica + ": ")).trim();
  if (!senha && !primeiraVez) break;
  if (senha.length < 8 || /[\s"%^&!|<>]/.test(senha)) { console.log("     Senha fora das regras. Tente de novo."); continue; }
  if (rodar(["env:set", "ADMIN_PASSWORD", senha]).status !== 0) falhar("Não foi possível gravar a senha no Netlify.");
  break;
}
rl.close();

console.log("\n5/5  Publicando em produção…");
const dep = rodar(["deploy", "--prod", "--json"], { capturar: true });
if (dep.status !== 0) falhar("A publicação falhou. Veja as mensagens acima.");
let url = "";
try {
  const j = JSON.parse(dep.stdout.slice(dep.stdout.indexOf("{")));
  url = j.url || j.site_url || "";
} catch {}
console.log("\n✅ Publicado!\n");
if (url) {
  console.log("   Link do CLIENTE : " + url);
  console.log("   Link do ADM     : " + url + "/admin   (pede a senha que você definiu)\n");
} else {
  console.log("   Abra o painel do Netlify para ver o endereço do site e acrescente /admin para o painel do ADM.\n");
}
