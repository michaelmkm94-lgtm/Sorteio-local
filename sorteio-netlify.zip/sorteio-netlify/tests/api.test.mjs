// Testes do fluxo completo com um "Netlify Blobs" em memória (mesma semântica de ETag/onlyIfNew/onlyIfMatch).
import test from "node:test";
import assert from "node:assert/strict";
import { createApp } from "../netlify/functions/lib/app.mjs";

function memoryStore() {
  const m = new Map();
  let n = 0;
  const lag = () => new Promise((r) => setTimeout(r, Math.random() * 3)); // força intercalação de requisições
  return {
    async getWithMetadata(k, { type } = {}) {
      await lag();
      const v = m.get(k);
      if (!v) return null;
      return { data: type === "json" ? JSON.parse(v.body) : v.body, etag: v.etag };
    },
    async get(k, { type } = {}) {
      await lag();
      const v = m.get(k);
      if (!v) return null;
      return type === "json" ? JSON.parse(v.body) : v.body;
    },
    async setJSON(k, data, o = {}) { return this.set(k, JSON.stringify(data), o); },
    async set(k, body, o = {}) {
      await lag();
      const cur = m.get(k);
      if (o.onlyIfNew && cur) return { modified: false };
      if (o.onlyIfMatch !== undefined && (!cur || cur.etag !== o.onlyIfMatch)) return { modified: false };
      const etag = `"e${++n}"`;
      m.set(k, { body, etag });
      return { modified: true, etag };
    },
    async delete(k) { m.delete(k); },
    async list({ prefix = "" } = {}) { return { blobs: [...m.keys()].filter((k) => k.startsWith(prefix)).map((key) => ({ key })) }; },
    _m: m,
  };
}

const PW = "senha-forte-123";
const setup = () => {
  const store = memoryStore();
  const handle = createApp({ store, adminPassword: PW });
  const call = async (method, path, body, { headers = {}, ip = "1.1.1.1" } = {}) => {
    const req = new Request("https://sorteio.example.app" + path, {
      method,
      headers: { "content-type": "application/json", ...headers },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const res = await handle(req, ip);
    const ct = res.headers.get("content-type") || "";
    return { status: res.status, headers: res.headers, json: ct.includes("json") ? await res.json() : null, res };
  };
  return { store, call };
};
const dev = (i) => `device-${String(i).padStart(24, "0")}`;
async function register(call, i, phone, amount = "300,00", extra = {}) {
  const a = await call("POST", "/api/entries/amount", { device_id: dev(i), purchase_amount: amount });
  if (a.status !== 200) return a;
  return call("POST", "/api/entries", {
    device_id: dev(i), full_name: "Cliente " + i, address: "Rua " + i, phone, purchase_amount: amount, ...extra,
  });
}

test("admin: sem senha configurada, bloqueia", async () => {
  const handle = createApp({ store: memoryStore(), adminPassword: "" });
  const r = await handle(new Request("https://x.app/api/auth", { method: "POST", body: JSON.stringify({ pin: "" }) }), "1.1.1.1");
  assert.equal(r.status, 503);
});

test("senha errada/certa, header e bloqueio por tentativas", async () => {
  const { call } = setup();
  assert.equal((await call("GET", "/api/admin")).status, 401);
  assert.equal((await call("GET", "/api/admin", undefined, { headers: { "x-admin-pin": PW } })).status, 200);
  assert.equal((await call("POST", "/api/auth", { pin: PW })).status, 200);
  for (let i = 0; i < 8; i++) assert.equal((await call("POST", "/api/auth", { pin: "x" + i }, { ip: "9.9.9.9" })).status, 401);
  assert.equal((await call("POST", "/api/auth", { pin: PW }, { ip: "9.9.9.9" })).status, 429); // bloqueado mesmo com a senha certa
  assert.equal((await call("POST", "/api/auth", { pin: PW }, { ip: "2.2.2.2" })).status, 200); // outro IP segue normal
});

test("rotas de administração exigem senha", async () => {
  const { call } = setup();
  for (const [m, p, b] of [["POST", "/api/settings", {}], ["POST", "/api/prizes", { name: "x" }], ["POST", "/api/draw", { prize_id: 1 }],
    ["POST", "/api/reset", {}], ["POST", "/api/entries/release", {}], ["POST", "/api/admin/entries", {}], ["POST", "/api/draw/finish", {}]]) {
    assert.equal((await call(m, p, b)).status, 401, p);
  }
});

test("cliente: valor → cadastro → status → duplicidade", async () => {
  const { call } = setup();
  const pub0 = await call("GET", "/api/public");
  assert.equal(pub0.json.participant_count, 0);
  assert.match(pub0.headers.get("netlify-cdn-cache-control"), /s-maxage=3/);

  const r = await register(call, 1, "(17) 99255-4403", "300,00");
  assert.equal(r.status, 200);
  assert.equal(r.json.tickets_total, 6);
  const st = await call("GET", "/api/entries/status?device_id=" + dev(1));
  assert.deepEqual([st.json.registered, st.json.tickets_total], [true, 6]);

  // mesmo aparelho
  assert.equal((await register(call, 1, "17992554404")).status, 409);
  // mesmo telefone em outro aparelho (inclusive com +55)
  const dup = await register(call, 2, "+55 17 99255-4403");
  assert.equal(dup.status, 409);
  assert.equal(dup.json.already_registered, true);
  // validações
  assert.equal((await register(call, 3, "1234")).status, 400);
  assert.equal((await call("POST", "/api/entries/amount", { device_id: dev(4), purchase_amount: "abc" })).status, 400);
  assert.equal((await call("POST", "/api/entries/amount", { device_id: "curto", purchase_amount: "10,00" })).status, 400);
  // valor diferente do confirmado
  await call("POST", "/api/entries/amount", { device_id: dev(5), purchase_amount: "100,00" });
  const bad = await call("POST", "/api/entries", { device_id: dev(5), full_name: "A", address: "B", phone: "17992554410", purchase_amount: "900,00" });
  assert.equal(bad.status, 409);
  // sem confirmar valor
  const noq = await call("POST", "/api/entries", { device_id: dev(6), full_name: "A", address: "B", phone: "17992554411", purchase_amount: "100,00" });
  assert.equal(noq.status, 409);
  // mínimo de 1 ficha
  const small = await register(call, 7, "17992554412", "10,00");
  assert.equal(small.json.tickets_total, 1);
});

test("corrida: 20 cadastros simultâneos com o mesmo telefone → só 1 entra", async () => {
  const { call } = setup();
  for (let i = 0; i < 20; i++) await call("POST", "/api/entries/amount", { device_id: dev(100 + i), purchase_amount: "50,00" });
  const rs = await Promise.all(Array.from({ length: 20 }, (_, i) =>
    call("POST", "/api/entries", { device_id: dev(100 + i), full_name: "N" + i, address: "R", phone: "17988887777", purchase_amount: "50,00" })));
  assert.equal(rs.filter((r) => r.status === 200).length, 1);
  assert.equal((await call("GET", "/api/public")).json.participant_count, 1);
});

test("corrida: 40 cadastros simultâneos de pessoas diferentes → todos entram, ids únicos", async () => {
  const { call } = setup();
  const phones = (i) => "1799" + String(1000000 + i);
  for (let i = 0; i < 40; i++) await call("POST", "/api/entries/amount", { device_id: dev(200 + i), purchase_amount: "80,00" });
  const rs = await Promise.all(Array.from({ length: 40 }, (_, i) =>
    call("POST", "/api/entries", { device_id: dev(200 + i), full_name: "N" + i, address: "R", phone: phones(i), purchase_amount: "80,00" })));
  assert.equal(rs.filter((r) => r.status === 200).length, 40, JSON.stringify(rs.filter((r) => r.status !== 200).map((r) => r.json)));
  const adm = await call("GET", "/api/admin", undefined, { headers: { "x-admin-pin": PW } });
  assert.equal(new Set(adm.json.entries.map((e) => e.id)).size, 40);
});

test("configurações: salvar, validar e refletir no público", async () => {
  const { call } = setup();
  assert.equal((await call("POST", "/api/settings", { pin: PW, draw_date: "14/11/2026" })).status, 400);
  assert.equal((await call("POST", "/api/settings", { pin: PW, draw_time: "9h" })).status, 400);
  const ok = await call("POST", "/api/settings", { pin: PW, draw_title: "Sorteio de Natal", draw_date: "2026-12-24", draw_time: "20:30", public_message: "Boa sorte!", accent_color: "red;}<script>", visual_theme: "hack" });
  assert.equal(ok.status, 200);
  const adm = await call("GET", "/api/admin", undefined, { headers: { "x-admin-pin": PW } });
  assert.equal(adm.json.settings.accent_color, "#77e5dc"); // valor inválido é descartado
  assert.equal(adm.json.settings.visual_theme, "neon-night");
  const pub = await call("GET", "/api/public");
  assert.equal(pub.json.settings.draw_title, "Sorteio de Natal");
  assert.equal(pub.json.settings.draw_datetime, "2026-12-24T20:30");
  assert.equal(pub.json.settings.accent_color, undefined); // não vaza campos administrativos
});

const PNG = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==";

test("prêmios, imagem, sorteio completo, sem repetir ficha, liberar ficha, finalizar e reset", async () => {
  const { call, store } = setup();
  const A = (b) => ({ pin: PW, ...b });
  await register(call, 1, "17990000001", "50,00"); // 1 ficha
  await register(call, 2, "17990000002", "50,00"); // 1 ficha
  assert.equal((await call("POST", "/api/prizes", A({ name: "TV", image: "data:text/html;base64,AAAA" }))).status, 400);
  const p1 = await call("POST", "/api/prizes", A({ name: "TV 50", description: "4K", image: PNG }));
  const p2 = await call("POST", "/api/prizes", A({ name: "Cesta" }));
  const p3 = await call("POST", "/api/prizes", A({ name: "Vale" }));
  assert.deepEqual([p1.json.id, p2.json.id, p3.json.id], [1, 2, 3]);

  const img = await call("GET", "/api/prize-image/1");
  assert.equal(img.status, 200);
  assert.equal(img.headers.get("content-type"), "image/png");
  assert.equal((await call("GET", "/api/prize-image/2")).status, 404);

  let adm = await call("GET", "/api/admin", undefined, { headers: { "x-admin-pin": PW } });
  assert.equal(adm.json.prizes[0].image, "/api/prize-image/1");
  assert.equal(adm.json.prizes[1].image, "");

  assert.equal((await call("POST", "/api/draw/start", A({ prize_id: 999 }))).status, 409);
  assert.equal((await call("POST", "/api/draw/start", A({ prize_id: 1 }))).status, 200);
  const d1 = await call("POST", "/api/draw", A({ prize_id: 1 }));
  assert.equal(d1.status, 200);
  assert.equal(d1.json.prize.image, "/api/prize-image/1");
  assert.equal(d1.json.winner.device_id, undefined); // dados internos não vazam
  assert.equal((await call("POST", "/api/draw", A({ prize_id: 1 }))).status, 400); // prêmio já sorteado

  const d2 = await call("POST", "/api/draw", A({ prize_id: 2 }));
  assert.notEqual(d2.json.winner.id, d1.json.winner.id); // ficha única não repete
  const d3 = await call("POST", "/api/draw", A({ prize_id: 3 }));
  assert.equal(d3.status, 400); // não há fichas disponíveis
  assert.equal(d3.json.error, "Não há participantes disponíveis.");

  // liberar ficha extra → pode sortear o último prêmio
  assert.equal((await call("POST", "/api/entries/release", A({ entry_id: 1, tickets: 0 }))).status, 400);
  assert.equal((await call("POST", "/api/entries/release", A({ entry_id: 77, tickets: 1 }))).status, 404);
  assert.equal((await call("POST", "/api/entries/release", A({ entry_id: 1, tickets: 2 }))).status, 200);
  const d4 = await call("POST", "/api/draw", A({ prize_id: 3 }));
  assert.equal(d4.status, 200);
  assert.equal(d4.json.winner.id, 1);

  const pub = await call("GET", "/api/public");
  assert.equal(pub.json.settings.draw_status, "finished");
  assert.equal(pub.json.results.length, 3);
  assert.deepEqual(pub.json.results.map((r) => r.prize_name), ["TV 50", "Cesta", "Vale"]);
  assert.equal(pub.json.available_tickets, 1); // 4 fichas liberadas (1+2 do #1, 1 do #2) − 3 sorteadas

  // novo prêmio reabre o sorteio
  await call("POST", "/api/prizes", A({ name: "Extra" }));
  assert.equal((await call("GET", "/api/public")).json.settings.draw_status, "running");
  // excluir: só prêmio não sorteado
  await call("POST", "/api/prizes/delete", A({ id: 1 }));
  await call("POST", "/api/prizes/delete", A({ id: 4 }));
  adm = await call("GET", "/api/admin", undefined, { headers: { "x-admin-pin": PW } });
  assert.deepEqual(adm.json.prizes.map((p) => p.id), [1, 2, 3]);

  assert.equal((await call("POST", "/api/draw/finish", A({}))).status, 200);
  assert.equal((await call("POST", "/api/draw/start", A({ prize_id: 1 }))).status, 409);

  // reset limpa tudo e libera os aparelhos
  assert.equal((await call("POST", "/api/reset", A({}))).status, 200);
  adm = await call("GET", "/api/admin", undefined, { headers: { "x-admin-pin": PW } });
  assert.equal(adm.json.entries.length + adm.json.prizes.length, 0);
  assert.equal(adm.json.settings.draw_status, "idle");
  assert.ok(![...store._m.keys()].some((k) => k.startsWith("img/") || k.startsWith("quote/")));
  assert.equal((await call("GET", "/api/entries/status?device_id=" + dev(1))).json.registered, false);
  // ids de prêmio não se repetem após o reset (cache de imagem seguro)
  assert.equal((await call("POST", "/api/prizes", A({ name: "Novo", image: PNG }))).json.id, 5);
});

test("cadastro manual do ADM e correção de valor (reset da cotação)", async () => {
  const { call } = setup();
  const A = (b) => ({ pin: PW, ...b });
  const m = await call("POST", "/api/admin/entries", A({ full_name: "Maria", address: "Rua A", phone: "17991112222", purchase_amount: "175,50" }));
  assert.equal(m.json.tickets_total, 3);
  const dup = await call("POST", "/api/admin/entries", A({ full_name: "Outra", address: "Rua B", phone: "17991112222" }));
  assert.equal(dup.status, 409);
  const zero = await call("POST", "/api/admin/entries", A({ full_name: "Zé", address: "Rua C", phone: "17993334444", purchase_amount: "" }));
  assert.equal(zero.json.tickets_total, 1);

  await call("POST", "/api/entries/amount", { device_id: dev(9), purchase_amount: "10,00" });
  assert.equal((await call("POST", "/api/entries/amount", { device_id: dev(9), purchase_amount: "20,00" })).status, 409);
  assert.equal((await call("POST", "/api/entries/amount/reset", { device_id: dev(9), pin: "errada" })).status, 401);
  assert.equal((await call("POST", "/api/entries/amount/reset", A({ device_id: dev(9) }))).status, 200);
  assert.equal((await call("POST", "/api/entries/amount", { device_id: dev(9), purchase_amount: "20,00" })).status, 200);
});

test("rota inexistente dá 404 e /api/qr não existe mais", async () => {
  const { call } = setup();
  assert.equal((await call("GET", "/api/nada")).status, 404);
  assert.equal((await call("GET", "/api/qr")).status, 404);
  assert.equal((await call("DELETE", "/api/public")).status, 404);
});

test("sorteio ponderado: 10 fichas ≈ 10x mais chance que 1 ficha; ficha cai a cada vitória", async () => {
  let vitoriasGrande = 0;
  const RODADAS = 300;
  for (let r = 0; r < RODADAS; r++) {
    const { call } = setup();
    const A = (b) => ({ pin: PW, ...b });
    // "Grande" = 500,00 → 10 fichas; "Pequeno" = 50,00 → 1 ficha
    await call("POST", "/api/admin/entries", A({ full_name: "Grande", address: "x", phone: "17990000001", purchase_amount: "500,00" }));
    await call("POST", "/api/admin/entries", A({ full_name: "Pequeno", address: "y", phone: "17990000002", purchase_amount: "50,00" }));
    await call("POST", "/api/prizes", A({ name: "P" }));
    const d = await call("POST", "/api/draw", A({ prize_id: 1 }));
    if (d.json.winner.full_name === "Grande") {
      vitoriasGrande++;
      assert.equal(d.json.winner.tickets_drawn, 1); // 10 → 9 restantes
    } else {
      assert.equal(d.json.winner.tickets_total - d.json.winner.tickets_drawn, 0); // 1 → 0, fora do restante
    }
  }
  // esperado ≈ 10/11 = 90,9%; uniforme seria 50%
  const taxa = vitoriasGrande / RODADAS;
  assert.ok(taxa > 0.82 && taxa < 0.97, "taxa observada: " + taxa);
});

test("quem tem 1 ficha e ganha sai do sorteio; quem tem 10 continua com 9", async () => {
  const { call } = setup();
  const A = (b) => ({ pin: PW, ...b });
  await call("POST", "/api/admin/entries", A({ full_name: "Solo", address: "x", phone: "17990000003", purchase_amount: "50,00" }));
  for (let i = 1; i <= 3; i++) await call("POST", "/api/prizes", A({ name: "P" + i }));
  const ganhou = new Map();
  for (let i = 1; i <= 3; i++) {
    const d = await call("POST", "/api/draw", A({ prize_id: i }));
    if (d.status === 200) ganhou.set(d.json.winner.full_name, (ganhou.get(d.json.winner.full_name) || 0) + 1);
    else assert.equal(d.status, 400);
  }
  assert.equal(ganhou.get("Solo"), 1); // única ficha: só ganha uma vez
});
